#!/usr/bin/env python3
"""Source-level integration checks; not a substitute for Android/NDK tests."""
from pathlib import Path
import re
import subprocess
import sys
root = Path(__file__).resolve().parents[1]
kotlin = (root / 'app/src/main/java/org/archime/ime/engine/NativeRimeEngine.kt').read_text()
contract = (root / 'app/src/main/java/org/archime/ime/engine/InputEngine.kt').read_text()
service = (root / 'app/src/main/java/org/archime/ime/ArchInputMethodService.kt').read_text()
cpp = (root / 'app/src/main/cpp/native_bridge.cpp').read_text()
cmake = (root / 'app/src/main/cpp/CMakeLists.txt').read_text()
methods = re.findall(r'private external fun (native\w+)\(', kotlin)
missing = [name for name in methods if f'NativeRimeEngine_{name}' not in cpp]
assert not missing, f'Missing JNI symbols: {missing}'
assert 'double_pinyin_mspy' in (root / 'app/src/main/assets/rime/default.custom.yaml').read_text()
assert 'RimeAssetInstaller.install(this, dir)' in service
installer = (root / 'app/src/main/java/org/archime/ime/engine/RimeAssetInstaller.kt').read_text()
assert 'if (output.exists())' in installer and 'InstallReport' in installer
assert 'rimeInstallFailed' in service
assert 'ARCHIME_RIME_DEPENDENCY_STAGED' in cmake
assert 'RIME_ROOT}/lib/${ANDROID_ABI}/librime.so' in cmake
assert 'jniLibs/${ANDROID_ABI}/librime.so' in cmake
assert 'RIME_API_AVAILABLE(h->api, get_context)' in cpp
assert 'RIME_API_AVAILABLE(h->api, select_candidate_on_current_page)' in cpp
for marker in ('rime_get_api()', 'create_session()', 'select_schema(', 'process_key(', 'get_context(', 'select_candidate_on_current_page(', 'destroy_session(', 'finalize()'):
    assert marker in cpp, f'Missing Rime lifecycle/API call: {marker}'
assert 'commitText: String' in contract and 'update.commitText' in service
assert '(Ljava/lang/String;Ljava/util/List;ZLjava/lang/String;)V' in cpp
print(f'PASS: {len(methods)} JNI entry points')
print('PASS: Rime lifecycle, schema selection, key processing, candidate extraction and teardown source paths')
stage_script = (root / 'tools/stage_rime_data.sh').read_text()
assert 'double_pinyin_mspy.schema.yaml' in stage_script and 'luna_pinyin.schema.yaml' in stage_script
assert 'rime_api.h' in (root / 'tools/check_native_bundle.sh').read_text()
stager = (root / 'tools/stage_librime_android.sh').read_text()
assert 'VENDOR_TMP/lib/$ABI/librime.so' in stager
assert 'jniLibs/$ABI' in stager
assert 'AArch64' in stager
print('PASS: committed text is propagated to InputConnection')
print('PASS: non-destructive asset installer and Rime data staging/preflight scripts')
print('LIMIT: source checks only; Android/NDK/librime compilation and device runtime remain unverified.')

# Xrepo CLI usage must follow documented platform/ABI/kind/config/fetch flags.
build_script = (root / 'tools/build_librime_android_xmake.sh').read_text()
for token in ('xrepo install -p android -a arm64-v8a', '--ndk=', '-k shared', '-f "shared=true"', 'xrepo fetch -p android', '--cflags', '--ldflags', '--plan', 'resolve_xrepo_librime.py'):
    assert token in build_script, f'Missing documented xrepo build step: {token}'
for obsolete in ('--plat=', '--arch=', '--configs=', '--installdir='):
    assert obsolete not in build_script, f'Obsolete/undocumented xrepo option remains: {obsolete}'
assert 'LDFLAGS=' in build_script and 'librime.so' in (root / 'tools/resolve_xrepo_librime.py').read_text()
print('PASS: documented xrepo Android ARM64 shared-build and package-cache resolution path')

assert 'button.text = if (shifted)' in service
assert 'override fun onFinishInput()' in service
assert 'if (rimeReady) renderUpdate(engine.clear())' in service
print('PASS: visible Shift state and editor lifecycle composition cleanup')

# Secure editor fields must bypass Rime; shifted Shuangpin keys stay lowercase.
assert 'private var secureField = false' in service
assert 'isSecureInput(info?.inputType ?: InputType.TYPE_NULL)' in service
assert 'InputType.TYPE_TEXT_VARIATION_PASSWORD' in service
assert 'InputType.TYPE_NUMBER_VARIATION_PASSWORD' in service
assert 'if (!isChineseActive()) { commit(c.toString()); return }' in service
assert 'engine.processKey(raw.lowercaseChar().code)' in service
assert 'commit(if (isChineseActive()) "，" else ",")' in service
assert 'commit(if (isChineseActive()) "。" else ".")' in service
print('PASS: password-field isolation and lowercase Shuangpin key handling')

# Native bundle audit must fail on missing non-platform DT_NEEDED entries.
auditor = (root / 'tools/audit_native_bundle.py').read_text()
assert 'AArch64' in auditor and 'DT_NEEDED' in auditor
assert 'unstaged dependencies' in auditor and 'PLATFORM_LIBS' in auditor
assert 'audit_native_bundle.py' in (root / 'tools/check_native_bundle.sh').read_text()
print('PASS: strict ARM64 ELF and native dependency-closure audit')

# 0.6.0 build workflow and safe Rime data staging.
stager = (root / 'tools/stage_rime_data.sh').read_text()
assert 'if [[ $# -ne 5 ]]' in stager
assert 'mktemp -d' in stager and 'shared-backup' in stager
assert 'mv "$STAGE" "$DEST"' in stager
doctor = (root / 'tools/doctor.sh').read_text()
for token in ('ANDROID_HOME', 'ANDROID_NDK_HOME', 'xrepo', 'double_pinyin_mspy.schema.yaml'):
    assert token in doctor
builder = (root / 'tools/build_debug_apk.sh').read_text()
assert ':app:assembleDebug' in builder and 'check_native_bundle.sh' in builder
assert 'Refusing to produce a misleading stub APK' in builder
print('PASS: prerequisite doctor, guarded APK build entry point, and staged-data rollback workflow')

# 0.6.1 transactional native staging must validate the candidate before activation.
native_stager = (root / 'tools/stage_librime_android.sh').read_text()
for token in ('mktemp -d', 'readelf -h', 'ARCHIME_ABI_DIR=', 'VENDOR_BACKUP', 'JNI_BACKUP', 'AArch64', 'audit_native_bundle.py'):
    assert token in native_stager, f'Missing transactional native-staging safeguard: {token}'
assert 'ARCHIME_ABI_DIR' in auditor
print('PASS: transactional ARM64 native staging with pre-activation ELF/dependency audit')

# 0.6.2: fail-closed validation of the Microsoft Shuangpin shared data bundle.
rime_check = (root / 'tools/check_rime_data.sh').read_text()
for token in ('default.yaml', 'luna_pinyin.schema.yaml', 'luna_pinyin.dict.yaml', 'double_pinyin_mspy.schema.yaml', 'verify_rime_config.py'):
    assert token in rime_check, f'Missing Rime data validation: {token}'
build_script = (root / 'tools/build_debug_apk.sh').read_text()
assert 'tools/check_rime_data.sh' in build_script
doctor = (root / 'tools/doctor.sh').read_text()
assert 'tools/check_rime_data.sh' in doctor
print('PASS: fail-closed Microsoft Shuangpin data preflight is wired into doctor and APK build')

# 0.6.3: official upstream Rime data fetch, lockfile and four-repository staging.
fetcher = (root / 'tools/fetch_rime_data.sh').read_text()
for token in ('rime-prelude.git', 'rime-essay.git', 'rime-luna-pinyin.git', 'rime-double-pinyin.git', 'rime-stroke.git', '--locked', 'rev-parse HEAD', 'rime-data.lock'):
    assert token in fetcher, f'Missing upstream data fetch/lock feature: {token}'
assert 'tools/stage_rime_data.sh' in fetcher and 'tools/check_rime_data.sh' in fetcher
stage_script = (root / 'tools/stage_rime_data.sh').read_text()
for token in ('essay.txt', 'default.yaml', 'double_pinyin_mspy.schema.yaml', 'luna_pinyin.dict.yaml'):
    assert token in stage_script, f'Missing required staged Rime data: {token}'
assert 'for source in "$PRELUDE" "$ESSAY" "$BASE" "$DOUBLE" "$STROKE"' in stage_script
assert 'essay.txt' in (root / 'tools/check_rime_data.sh').read_text()
print('PASS: official Rime upstream fetch, commit lock, five-repository staging and expanded data preflight')

# 0.6.4: isolated fetch workspace, strict lock validation, and publish-after-stage.
for token in ('mktemp -d', 'malformed lock entry', 'duplicate lock entry', 'lock is missing', 'fetched commit mismatch', 'stage_rime_data.sh', 'mv -f "$LOCK_TMP" "$LOCK"', '--help'):
    assert token in fetcher, f'Missing hardened upstream fetch behavior: {token}'
print('PASS: isolated Rime fetch, strict commit-lock validation, and publish-after-validation workflow')

# 0.6.5: native runtime diagnostics, maintenance sequencing, and notification cleanup.
for token in ('android/log.h', 'ArchIME-Rime', 'set_notification_handler', 'onRimeNotification',
              'waiting for Rime maintenance/deployment', 'Rime maintenance/deployment finished',
              'create_session failed', 'double_pinyin_mspy', 'get_version', 'librime finalized'):
    assert token in cpp, f'Missing native runtime diagnostic/lifecycle safeguard: {token}'
print('PASS: native librime lifecycle diagnostics, deployment sequencing and notification cleanup')


# 0.6.6: validate the app-owned schema selection against staged upstream metadata.
config_validator = (root / 'tools/verify_rime_config.py').read_text()
for token in ('double_pinyin_mspy', 'schema_id', 'dependencies', 'stroke', 'schema_list', 'default.custom.yaml', '--root', 'LIMIT: focused metadata validation only'):
    assert token in config_validator, f'Missing Rime config validation behavior: {token}'
assert 'tools/verify_rime_config.py' in (root / 'tools/check_rime_data.sh').read_text()
assert 'rime-stroke.git' in fetcher
assert 'stroke.schema.yaml' in rime_check and 'stroke.dict.yaml' in rime_check
assert 'versionCode = 71' in (root / 'app/build.gradle.kts').read_text()
assert 'versionName = "0.7.1-dev"' in (root / 'app/build.gradle.kts').read_text()
print('PASS: upstream-shaped Microsoft Shuangpin schema metadata, stroke dependency and app-owned selection validator')

# Run isolated regression fixtures for upstream-shaped Rime schema metadata.
subprocess.run([sys.executable, str(root / 'tools/test_verify_rime_config.py')], check=True)
print('PASS: isolated Rime metadata regression fixtures')

# 0.6.8: compile-time checks against the exact staged official librime header.
for token in (
    'std::is_same_v<decltype(RimeApi::setup)',
    'std::is_same_v<decltype(RimeApi::initialize)',
    'std::is_same_v<decltype(RimeApi::start_maintenance)',
    'std::is_same_v<decltype(RimeApi::create_session)',
    'std::is_same_v<decltype(RimeApi::select_schema)',
    'std::is_same_v<decltype(RimeApi::process_key)',
    'std::is_same_v<decltype(RimeApi::get_context)',
    'std::is_same_v<decltype(RimeApi::select_candidate_on_current_page)',
    'std::is_same_v<decltype(RimeApi::destroy_session)',
    'std::is_same_v<decltype(RimeApi::finalize)',
    'std::is_same_v<decltype(RimeApi::set_notification_handler)',
):
    assert token in cpp, f'Missing compile-time librime ABI contract: {token}'
assert 'versionCode = 71' in (root / 'app/build.gradle.kts').read_text()
assert 'versionName = "0.7.1-dev"' in (root / 'app/build.gradle.kts').read_text()
print('PASS: 0.6.8 compile-time librime API signature contract is wired into the staged native build')

# 0.6.9: xrepo output resolution must be isolated, deterministic and collision-safe.
resolver = (root / 'tools/resolve_xrepo_librime.py').read_text()
for token in ('shlex.split', 'rime_api.h', 'librime.so', 'conflicting shared-library basename', 'shutil.rmtree(include_out', 'shutil.rmtree(lib_out'):
    assert token in resolver, f'Missing xrepo artifact-resolution safeguard: {token}'
subprocess.run([sys.executable, str(root / 'tools/test_resolve_xrepo_librime.py')], check=True)
print('PASS: xrepo package-cache resolution, clean-prefix staging and conflicting dependency rejection')

# 0.7.0: reproducible GitHub Actions Android ARM64 build pipeline.
workflow = (root / '.github/workflows/android-arm64.yml').read_text()
for token in ('android-actions/setup-android@v3', 'ndk;27.2.12479018',
              'xmake-io/github-action-setup-xmake@v1', 'gradle/actions/setup-gradle@v4',
              'tools/fetch_rime_data.sh', 'tools/build_librime_android_xmake.sh',
              'tools/build_debug_apk.sh', 'actions/upload-artifact@v4',
              'arm64-v8a'):
    assert token in workflow, f'Missing CI build pipeline step: {token}'
assert 'versionCode = 71' in (root / 'app/build.gradle.kts').read_text()
assert 'versionName = "0.7.1-dev"' in (root / 'app/build.gradle.kts').read_text()
assert 'tools/collect_ci_diagnostics.sh' in workflow
assert '.build/ci/**' in workflow
assert 'tee .build/ci/rime-data.log' in workflow
assert 'tee .build/ci/librime-build.log' in workflow
assert 'tee .build/ci/android-build.log' in workflow
assert workflow.index('Fetch and validate official Rime schema data') < workflow.index('Build and stage librime for Android ARM64') < workflow.index('Run project and native bundle checks') < workflow.index('Build Debug APK')
assert 'if: always()' in workflow
diagnostics = (root / 'tools/collect_ci_diagnostics.sh').read_text()
for token in ('ANDROID_NDK_HOME', 'readelf -h', 'readelf -d', 'app-debug.apk', '.build/ci-diagnostics.txt'):
    assert token in diagnostics
print('PASS: CI pipeline ordering, failure log capture, and always-uploaded build diagnostics')
