plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.archime.ime"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.archime.ime"
        minSdk = 26
        targetSdk = 35
        versionCode = 71
        versionName = "0.7.1-dev"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild { cmake { cppFlags += "-std=c++17" } }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
}
