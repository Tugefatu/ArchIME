package org.archime.ime

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.text.InputType
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.archime.ime.engine.InputEngine
import org.archime.ime.engine.NativeRimeEngine
import org.archime.ime.engine.RimeAssetInstaller

/** ArchIME's first usable keyboard shell: English passthrough + Rime candidate UI hook. */
class ArchInputMethodService : InputMethodService() {
    private val engine = NativeRimeEngine()
    private var rimeReady = false
    private var rimeInstallFailed = false
    private var chineseMode = true
    private val mainHandler = Handler(Looper.getMainLooper())
    private var repeatingBackspace = false
    private val backspaceRepeat = object : Runnable {
        override fun run() {
            if (!repeatingBackspace) return
            onBackspace()
            mainHandler.postDelayed(this, 58L)
        }
    }
    private var shifted = false
    private var secureField = false
    private lateinit var status: TextView
    private lateinit var candidates: LinearLayout
    private lateinit var root: LinearLayout
    private val letterButtons = linkedMapOf<Char, Button>()
    private var visibleCandidates = emptyList<InputEngine.Candidate>()

    override fun onCreate() {
        super.onCreate()
        chineseMode = getSharedPreferences("archime_settings", MODE_PRIVATE).getBoolean("chinese_mode", true)
        val dir = filesDir.resolve("rime").apply { mkdirs() }
        val install = RimeAssetInstaller.install(this, dir)
        rimeInstallFailed = install.isFailure
        rimeReady = install.isSuccess && engine.initialize(dir.absolutePath)
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(10))
            background = acrylicPanel()
            elevation = dp(8).toFloat()
        }
        status = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFFB7C5D8.toInt())
            text = if (rimeReady) "ArchIME · Rime 已连接" else if (rimeInstallFailed) "ArchIME · 配置部署失败 | 英文可用" else "ArchIME · Rime 待接入 | 英文可用"
            setPadding(dp(5), dp(2), dp(5), dp(5))
        }
        root.addView(status)
        candidates = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(38)
        }
        root.addView(candidates)
        val numberRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        "1234567890".forEach { digit ->
            addKey(numberRow, digit.toString(), 1f, 40) { onDigit(digit) }
        }
        root.addView(numberRow)
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        rows.forEachIndexed { index, keys ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            if (index == 2) addKey(row, "⇧", 1.25f, 48) { shifted = !shifted; refreshKeyLabels() }
            keys.forEach { key ->
                val button = addKey(row, key.toString(), 1f, 48) { onLetter(key) }
                letterButtons[key] = button
            }
            if (index == 2) addBackspaceKey(row)
            root.addView(row)
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        addKey(bottom, if (chineseMode) "中" else "英", 1.15f, 48) {
            chineseMode = !chineseMode
            getSharedPreferences("archime_settings", MODE_PRIVATE).edit().putBoolean("chinese_mode", chineseMode).apply()
            status.text = inputStatus()
            renderUpdate(if (rimeReady) engine.clear() else InputEngine.Update("", emptyList(), false))
        }
        addKey(bottom, "，", .75f, 48) { commit(if (isChineseActive()) "，" else ",") }
        addKey(bottom, "空格", 3.8f, 48) { onSpace() }
        addKey(bottom, "。", .75f, 48) { commit(if (isChineseActive()) "。" else ".") }
        addKey(bottom, "↵", 1.15f, 48) { onEnter() }
        root.addView(bottom)
        refreshCandidates(emptyList())
        return root
    }

    private fun addKey(row: LinearLayout, label: String, weight: Float, height: Int, action: () -> Unit): Button {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = if (label.length > 1) 12f else 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = keyRipple(if (label == "空格") 0xAA526B8C.toInt() else 0xAA34445A.toInt())
            setPadding(0, 0, 0, 0)
            minWidth = 0
            setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); action() }
        }
        val lp = LinearLayout.LayoutParams(0, dp(height), weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        row.addView(button, lp)
        return button
    }

    private fun addBackspaceKey(row: LinearLayout) {
        val button = Button(this).apply {
            text = "⌫"
            isAllCaps = false
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = keyRipple(0xAA34445A.toInt())
            setPadding(0, 0, 0, 0)
            minWidth = 0
            setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onBackspace() }
            setOnLongClickListener {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                repeatingBackspace = true
                mainHandler.postDelayed(backspaceRepeat, 420L)
                true
            }
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                    repeatingBackspace = false
                    mainHandler.removeCallbacks(backspaceRepeat)
                }
                false
            }
        }
        row.addView(button, LinearLayout.LayoutParams(0, dp(48), 1.25f).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        })
    }

    private fun keyRipple(baseColor: Int) = RippleDrawable(
        ColorStateList.valueOf(0x557FC4FF),
        GradientDrawable().apply {
            setColor(baseColor)
            cornerRadius = dp(11).toFloat()
            setStroke(dp(1), 0x337FC4FF)
        },
        null
    )

    /** Acrylic-inspired layered surface; intentionally a visual fallback, not real backdrop blur. */
    private fun acrylicPanel() = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(0xF02B3545.toInt(), 0xF018202D.toInt(), 0xF0141B27.toInt())
    ).apply {
        cornerRadius = dp(22).toFloat()
        setStroke(dp(1), 0x557FC4FF)
    }

    private fun onLetter(raw: Char) {
        val c = if (shifted) raw.uppercaseChar() else raw
        shifted = false
        refreshKeyLabels()
        if (!isChineseActive()) { commit(c.toString()); return }
        if (!rimeReady) {
            status.text = "中文引擎尚未接入；切换「英」可正常输入"
            return
        }
        // Rime schemas expect lowercase ASCII even when visual Shift is enabled.
        renderUpdate(engine.processKey(raw.lowercaseChar().code))
    }

    private fun onDigit(digit: Char) {
        val candidateIndex = digit.digitToIntOrNull()?.let { if (it == 0) 9 else it - 1 }
        if (isChineseActive() && rimeReady && candidateIndex != null && candidateIndex < visibleCandidates.size) {
            renderUpdate(engine.selectCandidate(candidateIndex))
        } else {
            commit(digit.toString())
        }
    }

    private fun onBackspace() {
        if (isChineseActive() && rimeReady) renderUpdate(engine.backspace())
        else currentInputConnection?.deleteSurroundingText(1, 0)
    }

    private fun onSpace() {
        if (isChineseActive() && rimeReady) {
            val update = engine.processKey(' '.code)
            renderUpdate(update)
            if (update.composingText.isEmpty() && update.candidates.isEmpty() && update.commitText.isEmpty()) currentInputConnection?.commitText(" ", 1)
        } else commit(" ")
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
        else ic.commitText("\n", 1)
    }

    private fun renderUpdate(update: InputEngine.Update) {
        val ic = currentInputConnection
        if (update.commitText.isNotEmpty()) {
            ic?.commitText(update.commitText, 1)
            ic?.finishComposingText()
        }
        if (update.ready) ic?.setComposingText(update.composingText, 1)
        refreshCandidates(update.candidates)
        if (update.ready) status.text = "ArchIME · 中文引擎运行中"
    }

    private fun refreshCandidates(items: List<InputEngine.Candidate>) {
        if (!::candidates.isInitialized) return
        candidates.removeAllViews()
        visibleCandidates = items.take(5)
        if (visibleCandidates.isNotEmpty()) {
            addCandidateNav("‹") { renderUpdate(engine.changePage(true)) }
        }
        visibleCandidates.forEachIndexed { index, candidate ->
            val item = TextView(this).apply {
                text = "${index + 1} ${candidate.text}"
                textSize = 15f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(9), dp(5), dp(9), dp(5))
                setOnClickListener { renderUpdate(engine.selectCandidate(index)) }
            }
            candidates.addView(item, LinearLayout.LayoutParams(0, dp(38), 1f))
        }
        if (visibleCandidates.isNotEmpty()) {
            addCandidateNav("›") { renderUpdate(engine.changePage(false)) }
        }
        if (items.isEmpty()) {
            val hint = TextView(this).apply {
                text = when {
                    secureField -> "安全输入 · English only"
                    chineseMode -> "双拼候选栏 · 等待 Rime"
                    else -> "English input"
                }
                textSize = 12f
                setTextColor(0xFF8292A8.toInt())
                gravity = Gravity.CENTER_VERTICAL
            }
            candidates.addView(hint)
        }
    }

    private fun addCandidateNav(label: String, action: () -> Unit) {
        val nav = TextView(this).apply {
            text = label
            textSize = 23f
            setTextColor(0xFFB7C5D8.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(5), 0, dp(5), 0)
            setOnClickListener { action() }
        }
        candidates.addView(nav, LinearLayout.LayoutParams(dp(28), dp(38)))
    }

    private fun refreshKeyLabels() {
        letterButtons.forEach { (key, button) -> button.text = if (shifted) key.uppercaseChar().toString() else key.toString() }
    }
    private fun isChineseActive() = chineseMode && !secureField

    private fun inputStatus(): String = when {
        secureField -> "ArchIME · 安全输入 · 不启用中文引擎"
        chineseMode -> "ArchIME · ${if (rimeReady) "Rime 已连接" else "中文引擎未就绪"}"
        else -> "ArchIME · English mode"
    }

    private fun isSecureInput(inputType: Int): Boolean {
        val inputClass = inputType and InputType.TYPE_MASK_CLASS
        val variation = inputType and InputType.TYPE_MASK_VARIATION
        return (inputClass == InputType.TYPE_TEXT && variation in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        )) || (inputClass == InputType.TYPE_NUMBER &&
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    private fun commit(value: String) { currentInputConnection?.commitText(value, 1) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Never carry a half-typed syllable into a different editor/view.
        secureField = isSecureInput(info?.inputType ?: InputType.TYPE_NULL)
        if (rimeReady) renderUpdate(engine.clear())
        currentInputConnection?.finishComposingText()
        status.text = inputStatus()
        shifted = false
        refreshKeyLabels()
    }

    override fun onFinishInput() {
        if (rimeReady) {
            val update = engine.clear()
            currentInputConnection?.setComposingText("", 1)
            refreshCandidates(update.candidates)
        }
        super.onFinishInput()
    }

    override fun onDestroy() {
        repeatingBackspace = false
        mainHandler.removeCallbacks(backspaceRepeat)
        engine.close()
        super.onDestroy()
    }
}
