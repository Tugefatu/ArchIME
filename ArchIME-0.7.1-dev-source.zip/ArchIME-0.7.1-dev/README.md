# ArchIME 0.7.1-dev

Android input-method prototype targeting ARM64 devices, with an acrylic-inspired keyboard shell, English passthrough, candidate UI, and a conditional JNI/librime integration.

## 0.6.1-dev changes

- Reworked `tools/stage_librime_android.sh` to stage a matching librime header and shared libraries into temporary directories first.
- Requires `readelf`, verifies every candidate shared object is AArch64, and audits the candidate `DT_NEEDED` dependency closure before replacing existing staged files.
- Replaces the previous native bundle transactionally with backup/rollback behavior; stale `.so` files from earlier builds are not silently retained.
- Extended the source checker to cover the native staging safeguards.
- Bumped Android version metadata to 0.6.1-dev (versionCode 61).

Validation in this environment: Python source checks, shell syntax checks, and archive integrity. No Android SDK/NDK, Gradle build, xmake/xrepo execution, ARM64 librime build, APK, or physical-device test is claimed.


## 0.6.2-dev changes

- Added `tools/check_rime_data.sh` to verify the minimum shared Rime deployment files: `default.yaml`, the base Luna Pinyin schema and dictionary, and the Microsoft Shuangpin schema.
- Verifies the expected schema IDs instead of treating the presence of one schema filename as proof that the full deployment is ready.
- Wired the data preflight into both `tools/doctor.sh` and `tools/build_debug_apk.sh`; APK creation now refuses to proceed when required schema/data files are missing.
- Bumped Android version metadata to 0.6.2-dev (versionCode 62).

Validation in this environment: source checks, shell syntax checks, and ZIP integrity. No upstream Rime data was downloaded or staged, no Android build was run, and no APK/device test is claimed.

Run `tools/check_rime_data.sh` after `tools/stage_rime_data.sh` to verify the shared-data bundle.

## Stage native librime

Build or obtain an Android ARM64 librime prefix containing:

- `include/rime_api.h`
- `lib/librime.so` (or `lib64/librime.so`)
- every non-platform shared dependency in the same library directory

Then run:

```bash
./tools/stage_librime_android.sh /path/to/android-librime-prefix
```

The script validates the complete candidate bundle before replacing the currently staged native files. It requires `readelf`. After staging, run `tools/doctor.sh`, `tools/check_native_bundle.sh`, and `tools/build_debug_apk.sh` with a complete Android SDK/NDK/Gradle toolchain and staged Microsoft Shuangpin shared data.

## Important status

This archive is source code, not an APK. The librime JNI branch has not been compiled or run here. Successful source checks and ELF metadata checks do not prove Android runtime compatibility or functional Chinese input. Linux remains a separate Fcitx5 + Rime integration target.


## 0.6.3-dev changes

- Added `tools/fetch_rime_data.sh` to fetch the official `rime-prelude`, `rime-essay`, `rime-luna-pinyin`, and `rime-double-pinyin` repositories.
- The first fetch records the exact upstream commit IDs in `rime-data.lock`; subsequent `--locked` runs fetch those exact commits for repeatable data staging.
- Expanded the staging transaction to assemble all four repositories into a clean directory, validate required files and schema IDs, and only then activate the new shared-data directory.
- Expanded the Rime data preflight to require `essay.txt` as well as the schemas, dictionary and prelude configuration.
- Bumped Android version metadata to 0.6.3-dev (versionCode 63).

Run `tools/fetch_rime_data.sh` with network access to fetch current official data and create `rime-data.lock`. Commit that lock file with the project; on another machine use `tools/fetch_rime_data.sh --locked` to stage the same upstream revisions. The script requires Git and network access.

Validation in this environment: static source checks, shell syntax checks, and ZIP integrity only. The upstream repositories were not downloaded in this environment; data compilation, Android/NDK builds, APK generation, and device input remain unverified.

## 0.6.4-dev changes

- Hardened `tools/fetch_rime_data.sh` with an isolated temporary Git workspace; incomplete clones no longer destroy the previous fetch workspace.
- Locked mode now rejects malformed, duplicate, unknown, missing, or non-40-character commit entries and verifies that each fetched checkout exactly matches its pinned commit.
- The active Rime shared-data bundle is staged and validated before a newly resolved lockfile is published. A failed fetch or validation therefore leaves the existing lockfile unchanged; the data stager retains its own backup/rollback behavior.
- Added `--help` and clearer command usage.
- Bumped Android version metadata to 0.6.4-dev (versionCode 64).

Validation in this environment: shell syntax, Python source checks, project consistency checks, and ZIP integrity. Network fetch of upstream repositories, data compilation, Android/NDK builds, APK generation, and physical-device input remain unverified.


## 0.6.5-dev changes

- Added Android logcat diagnostics around librime setup, initialization, maintenance/deployment, session creation, Microsoft Shuangpin schema selection, runtime version reporting, and shutdown.
- Registered a librime notification callback when the versioned API exposes it, so schema/deployment notifications are visible in logcat during device testing.
- Clears the notification callback before finalization and on session/schema initialization failures to avoid retaining a callback into a torn-down runtime.
- Added explicit logs for session creation and schema-selection failures instead of silently returning an unavailable engine.
- Bumped Android version metadata to 0.6.5-dev (versionCode 65).

For device diagnostics, run `adb logcat -s ArchIME-Rime:I`. These logs help distinguish native-library loading, data deployment, session creation, and schema-selection failures.

Validation in this environment: source-level checks, shell/Python syntax checks, and ZIP integrity. Android NDK compilation, librime runtime behavior, APK generation, and physical-device Chinese input remain unverified.


## 0.6.6-dev changes

- Added `tools/verify_rime_config.py` to verify that the staged Microsoft Shuangpin schema declares the expected schema ID and that ArchIME's `default.custom.yaml` selects that schema.
- Wired the focused reference check into `tools/check_rime_data.sh`; missing shared data is reported as a skip by the standalone validator, while the full data preflight remains fail-closed.
- Added `--root` support so the validator can be tested against isolated fixture projects without modifying the working tree.
- Bumped Android version metadata to 0.6.6-dev (versionCode 66).

Validation in this environment: Python source checks, shell syntax checks, isolated positive/negative schema-reference fixtures, and ZIP integrity. This validator checks selected YAML references only; it does not compile Rime schemas. Android NDK/librime compilation, APK generation, and physical-device input remain unverified.


## 0.6.7-dev changes

- Cross-checked the Microsoft Shuangpin schema against the official `rime/rime-double-pinyin` repository. Its actual YAML structure is `schema:` followed by the nested `schema_id:` field; the previous validator's scalar `schema:` assumption did not match upstream.
- Fixed schema metadata validation to read the upstream `schema.schema_id` and `schema.dependencies` structure.
- Added the official `rime/rime-stroke` repository to the locked upstream fetch and transactional staging workflow because the Microsoft Shuangpin schema declares `stroke` as a dependency. References: https://github.com/rime/rime-double-pinyin and https://github.com/rime/rime-stroke.
- Required `stroke.schema.yaml` and `stroke.dict.yaml` during data preflight, and validated the dependency declaration and app-owned schema selection before activating staged data.
- Expanded isolated fixtures to cover the upstream-shaped YAML, wrong schema ID, missing dependency declaration, missing stroke files, and wrong app selection.
- Bumped Android version metadata to 0.6.7-dev (versionCode 67).

Validation in this environment: isolated positive/negative metadata fixtures, a five-repository staging simulation using upstream-shaped fixtures, Python and shell syntax checks, source consistency checks, and ZIP integrity. GitHub source pages were inspected, but a direct Git fetch attempt could not resolve `github.com` in this environment, so the five upstream repositories were not downloaded. Rime schema compilation, Android NDK/librime compilation, APK generation, and physical-device input remain unverified.


## 0.6.8-dev changes

- Added compile-time C++ `static_assert` checks for the exact librime API function-pointer signatures used by the JNI bridge: setup, initialize, maintenance, session lifecycle, schema selection, key processing, context extraction, candidate selection, notification callback, and finalization.
- The checks compile only when the ARM64 librime header/library bundle is staged. A mismatched or incompatible `rime_api.h` now fails the real Android native build instead of silently compiling against an assumed API contract.
- The assertions are based on the upstream `rime_api.h` declarations. See https://github.com/rime/librime/blob/master/src/rime_api.h.
- Bumped Android version metadata to 0.6.8-dev (versionCode 68).

Validation in this environment: source-level checker, Python/Shell syntax checks, and ZIP integrity. The compile-time assertions have **not** been executed here because Android NDK and a staged ARM64 librime header/library are unavailable. No APK or device input test is claimed.


## 0.6.9-dev changes

- Added `tools/resolve_xrepo_librime.py` to parse documented xrepo `-I`/`-L` output, locate `rime_api.h` and `librime.so`, and collect package shared libraries into a clean prefix.
- Handles both joined and separated include/library flags and quoted paths.
- Rejects conflicting shared-library basenames instead of silently choosing one, and clears stale include/lib output before staging.
- Added isolated resolver regression tests for paths with spaces, transitive shared-library collection, conflicting duplicates, and missing `librime.so`.
- Improved `tools/build_librime_android_xmake.sh` with `--plan`, clearer prerequisite checks, empty-flag rejection, and the isolated resolver.
- Bumped Android version metadata to 0.6.9-dev (versionCode 69).

The Xrepo package index lists librime for Android arm64-v8a; Xrepo documents `xrepo install -p android --ndk=...`, shared-package selection, and `xrepo fetch --cflags/--ldflags`. References: https://xrepo.xmake.io/ and https://xrepo.xmake.io/mirror/packages/android.html.

Validation in this environment: source checks, isolated resolver tests, Python/Shell syntax, build-plan output, and ZIP integrity. This environment still lacks xmake/xrepo and Android NDK, so no package download, ARM64 compilation, APK build, or physical-device test is claimed.


## 0.7.0-dev changes

- Added `.github/workflows/android-arm64.yml`, a GitHub Actions pipeline for Android ARM64.
- CI provisions Java 17, Android SDK platform 35, NDK r27d, CMake 3.22.1, Xmake/Xrepo and Gradle 8.9.
- CI fetches and validates official Rime data, builds/stages the Xrepo librime Android ARM64 package, audits native dependencies, builds the Debug APK, and uploads it as a workflow artifact.
- Added artifact retention for the APK and native build diagnostics.
- Bumped Android version metadata to 0.7.0-dev (versionCode 70).

How to use: push this project to a GitHub repository, then open Actions and run "Android ARM64 build" via workflow_dispatch. A successful run will publish `ArchIME-debug-arm64` as a downloadable workflow artifact.

The workflow has been authored and statically inspected locally, but has **not** been executed on GitHub Actions. It is not evidence that librime has built or that an APK exists yet. The first CI run may expose upstream package recipe or toolchain compatibility issues that will need correction.


## 0.7.1-dev changes

- Wrapped the Rime data fetch, librime build, project checks, and APK build commands in `pipefail`-safe log capture. CI now preserves the full output of each major stage instead of relying only on the truncated Actions console.
- Added `tools/collect_ci_diagnostics.sh`, which records toolchain versions, runner architecture, SDK/NDK paths, staged native files, ARM64 ELF headers, `DT_NEEDED` entries, APK presence, and available disk space.
- The diagnostics collection step runs with `if: always()` and the artifact upload includes stage logs and the diagnostics report, including when an earlier build step fails.
- Strengthened source checks for CI stage ordering, log capture, and always-run diagnostics.
- Bumped Android version metadata to 0.7.1-dev (versionCode 71).

Validation in this environment: source checks, isolated resolver/schema fixtures, shell syntax checks, and archive integrity. GitHub Actions has not yet been run; this change improves failure visibility but does not establish that the upstream Android ARM64 build succeeds. No APK or physical-device test is claimed.
