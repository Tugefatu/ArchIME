#!/usr/bin/env python3
"""Audit packaged Android ARM64 shared-library ABI and DT_NEEDED closure."""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
ABI_DIR = Path(__import__("os").environ.get("ARCHIME_ABI_DIR", ROOT / "app/src/main/jniLibs/arm64-v8a")).resolve()
PLATFORM_LIBS = {
    "libandroid.so", "libc.so", "libdl.so", "libEGL.so", "libGLESv1_CM.so",
    "libGLESv2.so", "libjnigraphics.so", "liblog.so", "libm.so",
    "libmediandk.so", "libnativewindow.so", "libOpenSLES.so", "libsync.so",
    "libvulkan.so", "libz.so",
}


def run_readelf(*args: str) -> str:
    proc = subprocess.run(["readelf", *args], text=True, capture_output=True)
    if proc.returncode:
        raise RuntimeError(proc.stderr.strip() or f"readelf {' '.join(args)} failed")
    return proc.stdout


def main() -> int:
    readelf = shutil.which("readelf")
    if not readelf:
        print("ERROR: readelf is required for a reliable native bundle audit.", file=sys.stderr)
        return 2
    if not ABI_DIR.is_dir():
        print(f"ERROR: missing native library directory: {ABI_DIR}", file=sys.stderr)
        return 2

    libraries = sorted(p for p in ABI_DIR.iterdir() if p.is_file() and ".so" in p.name)
    if not libraries:
        print("ERROR: no packaged shared libraries found.", file=sys.stderr)
        return 2

    packaged = {p.name for p in libraries}
    failures: list[str] = []
    unresolved: dict[str, list[str]] = {}
    for library in libraries:
        try:
            header = run_readelf("-h", str(library))
            machine_match = re.search(r"^\s*Machine:\s*(.+)$", header, re.M)
            machine = machine_match.group(1).strip() if machine_match else "unknown"
            if "AArch64" not in machine:
                failures.append(f"{library.name}: expected AArch64 ELF, got {machine}")
                continue
            dynamic = run_readelf("-d", str(library))
            needed = re.findall(r"Shared library: \[(.+?)\]", dynamic)
            missing = sorted(dep for dep in needed if dep not in PLATFORM_LIBS and dep not in packaged)
            if missing:
                unresolved[library.name] = missing
        except (RuntimeError, OSError) as exc:
            failures.append(f"{library.name}: {exc}")

    if failures:
        for failure in failures:
            print(f"ERROR: {failure}", file=sys.stderr)
    if unresolved:
        for library, deps in unresolved.items():
            print(f"ERROR: {library} has unstaged dependencies: {', '.join(deps)}", file=sys.stderr)
    if failures or unresolved:
        return 1

    print(f"PASS: {len(libraries)} packaged shared object(s) are AArch64")
    print("PASS: every DT_NEEDED dependency is either an Android platform library or packaged")
    print("NOTE: ELF closure does not guarantee ABI/API compatibility or successful runtime loading.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
