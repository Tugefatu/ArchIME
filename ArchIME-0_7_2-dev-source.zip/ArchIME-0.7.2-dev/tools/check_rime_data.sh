#!/usr/bin/env bash
# Fail-closed validation of the minimum shared Rime data required by ArchIME.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DATA="$ROOT/app/src/main/assets/rime/shared"
required=(default.yaml essay.txt luna_pinyin.schema.yaml luna_pinyin.dict.yaml double_pinyin_mspy.schema.yaml stroke.schema.yaml stroke.dict.yaml)
missing=0
for file in "${required[@]}"; do
  if [[ -s "$DATA/$file" ]]; then
    printf 'OK   %s (%s bytes)\n' "$file" "$(wc -c < "$DATA/$file" | tr -d ' ')"
  else
    printf 'MISS %s\n' "$file" >&2
    missing=$((missing + 1))
  fi
done
if (( missing )); then
  echo "ERROR: $missing required Rime data file(s) missing/empty." >&2
  echo "Fetch and stage official data with tools/fetch_rime_data.sh before building." >&2
  exit 1
fi
python3 "$ROOT/tools/verify_rime_config.py"
echo 'PASS: minimum Microsoft Shuangpin shared data and declared dependencies are present.'
