#!/usr/bin/env python3
"""Validate ArchIME's Microsoft Shuangpin schema and its declared dependencies.

This is a focused parser for the schema metadata subset used by upstream Rime
YAML files. It is not a general YAML parser and does not compile Rime schemas.
"""
from pathlib import Path
import argparse
import re
import sys

LIST_ITEM = re.compile(r"^\s{4}-\s*([A-Za-z0-9_.-]+)\s*(?:#.*)?$")


def schema_metadata(path: Path) -> tuple[str | None, list[str]]:
    """Read schema.schema_id and schema.dependencies from Rime's schema map."""
    in_schema = False
    in_dependencies = False
    schema_id = None
    dependencies: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()
        if indent == 0:
            in_schema = stripped == "schema:"
            in_dependencies = False
            continue
        if not in_schema:
            continue
        if indent == 2 and stripped.startswith("schema_id:"):
            match = re.match(r"^schema_id:\s*([A-Za-z0-9_.-]+)\s*(?:#.*)?$", stripped)
            schema_id = match.group(1) if match else None
            in_dependencies = False
        elif indent == 2 and stripped == "dependencies:":
            in_dependencies = True
        elif indent == 2:
            in_dependencies = False
        elif in_dependencies and indent == 4:
            match = LIST_ITEM.match(line)
            if match:
                dependencies.append(match.group(1))
    return schema_id, dependencies


def custom_schema_ids(path: Path) -> list[str]:
    lines = path.read_text(encoding="utf-8").splitlines()
    in_schema_list = False
    ids: list[str] = []
    for line in lines:
        if re.match(r"^\s{2}schema_list:\s*(?:#.*)?$", line):
            in_schema_list = True
            continue
        if in_schema_list and line and not line.startswith(" ") and not line.startswith("#"):
            break
        if in_schema_list:
            match = re.match(r"^\s{4}-\s*schema:\s*([A-Za-z0-9_.-]+)\s*(?:#.*)?$", line)
            if match:
                ids.append(match.group(1))
    return ids


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1],
                        help="project root (defaults to this script's parent project)")
    args = parser.parse_args()
    shared = args.root / "app/src/main/assets/rime/shared"
    custom = args.root / "app/src/main/assets/rime/default.custom.yaml"
    expected = "double_pinyin_mspy"
    schema_file = shared / f"{expected}.schema.yaml"
    if not schema_file.is_file() or schema_file.stat().st_size == 0:
        print(f"SKIP: shared schema data is not staged ({schema_file})")
        return 2
    actual, dependencies = schema_metadata(schema_file)
    if actual != expected:
        print(f"ERROR: {schema_file.name} declares schema id {actual!r}, expected {expected!r}", file=sys.stderr)
        return 1
    if "stroke" not in dependencies:
        print(f"ERROR: {schema_file.name} must declare the upstream stroke dependency; found {dependencies!r}", file=sys.stderr)
        return 1
    for filename in ("stroke.schema.yaml", "stroke.dict.yaml"):
        target = shared / filename
        if not target.is_file() or target.stat().st_size == 0:
            print(f"ERROR: Microsoft Shuangpin dependency is missing: {filename}", file=sys.stderr)
            return 1
    stroke_id, _ = schema_metadata(shared / "stroke.schema.yaml")
    if stroke_id != "stroke":
        print(f"ERROR: stroke.schema.yaml declares schema id {stroke_id!r}, expected 'stroke'", file=sys.stderr)
        return 1
    luna_file = shared / "luna_pinyin.schema.yaml"
    if not luna_file.is_file() or luna_file.stat().st_size == 0:
        print("ERROR: base Luna Pinyin schema is missing", file=sys.stderr)
        return 1
    luna_id, _ = schema_metadata(luna_file)
    if luna_id != "luna_pinyin":
        print(f"ERROR: luna_pinyin.schema.yaml declares schema id {luna_id!r}, expected 'luna_pinyin'", file=sys.stderr)
        return 1
    if not custom.is_file():
        print(f"ERROR: ArchIME user patch is missing: {custom}", file=sys.stderr)
        return 1
    refs = custom_schema_ids(custom)
    if expected not in refs:
        print(f"ERROR: default.custom.yaml schema_list does not include {expected!r}; found {refs!r}", file=sys.stderr)
        return 1
    print(f"PASS: {schema_file.name} declares {expected}")
    print("PASS: Microsoft Shuangpin stroke dependency and schema/dictionary files are present")
    print("PASS: default.custom.yaml selects Microsoft Shuangpin")
    print("LIMIT: focused metadata validation only; YAML compilation and librime runtime are not tested")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
