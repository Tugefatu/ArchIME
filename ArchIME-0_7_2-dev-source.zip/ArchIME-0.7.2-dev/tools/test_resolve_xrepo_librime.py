#!/usr/bin/env python3
"""Isolated tests for parsing xrepo flags and collecting shared libraries."""
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
RESOLVER = ROOT / "tools/resolve_xrepo_librime.py"


def run(cflags: str, ldflags: str, prefix: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(RESOLVER), f"--cflags={cflags}",
         f"--ldflags={ldflags}", "--prefix", str(prefix)],
        text=True, capture_output=True,
    )


with tempfile.TemporaryDirectory(prefix="archime-xrepo-test-") as temp:
    root = Path(temp)
    inc_a, inc_b = root / "inc a", root / "inc-b"
    lib_a, lib_b = root / "lib a", root / "lib-b"
    for directory in (inc_a, inc_b, lib_a, lib_b):
        directory.mkdir()
    (inc_b / "rime_api.h").write_text("/* fake test header */\n")
    (lib_a / "librime.so").write_bytes(b"rime-test")
    (lib_a / "libdep.so").write_bytes(b"dep-test")
    (lib_b / "libdep.so").write_bytes(b"dep-test")
    prefix = root / "prefix"
    good = run(f'-I"{inc_a}" -I "{inc_b}"',
               f'-L"{lib_a}" -L "{lib_b}" -lrime', prefix)
    assert good.returncode == 0, good.stderr
    assert (prefix / "include/rime_api.h").is_file()
    assert (prefix / "lib/librime.so").read_bytes() == b"rime-test"
    assert (prefix / "lib/libdep.so").read_bytes() == b"dep-test"

    (lib_b / "libdep.so").write_bytes(b"conflicting-dep")
    conflict = run(f'-I"{inc_b}"', f'-L"{lib_a}" -L"{lib_b}" -lrime', root / "bad")
    assert conflict.returncode != 0
    assert "conflicting shared-library basename libdep.so" in conflict.stderr

    missing = run(f'-I"{inc_b}"', f'-L"{lib_b}" -lmissing', root / "missing")
    assert missing.returncode != 0
    assert "librime.so" in missing.stderr

print("PASS: xrepo flag parsing, isolated prefix creation, dependency collection and collision rejection")
