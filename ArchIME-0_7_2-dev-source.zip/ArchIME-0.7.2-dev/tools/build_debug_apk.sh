#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ -x ./gradlew ]]; then GRADLE=./gradlew
elif command -v gradle >/dev/null 2>&1; then GRADLE=gradle
else echo 'ERROR: Gradle wrapper/installation not found.' >&2; exit 2; fi
if [[ -s app/src/main/cpp/vendor/librime/include/rime_api.h && -s app/src/main/jniLibs/arm64-v8a/librime.so ]]; then
  tools/check_native_bundle.sh
  tools/check_rime_data.sh
else
  echo 'ERROR: ARM64 librime is not fully staged. Refusing to produce a misleading stub APK.' >&2
  echo 'Run tools/doctor.sh and tools/build_librime_android_xmake.sh first.' >&2
  exit 2
fi
"$GRADLE" --no-daemon :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[[ -s "$APK" ]] || { echo "ERROR: Gradle finished but APK not found at $APK" >&2; exit 1; }
echo "SUCCESS: $APK"
