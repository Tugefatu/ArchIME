#!/usr/bin/env python3
"""Isolated positive/negative tests for the upstream-shaped Rime config validator."""
from pathlib import Path
import subprocess
import sys
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
VALIDATOR = PROJECT / "tools/verify_rime_config.py"
PATCH = "patch:\n  schema_list:\n    - schema: double_pinyin_mspy\n"
SCHEMA = "schema:\n  schema_id: double_pinyin_mspy\n  dependencies:\n    - stroke\n"
STROKE = "schema:\n  schema_id: stroke\n"


def run_case(schema_text: str = SCHEMA, patch_text: str = PATCH,
             with_stroke: bool = True) -> subprocess.CompletedProcess[str]:
    with tempfile.TemporaryDirectory(prefix="archime-schema-test-") as tmp:
        root = Path(tmp)
        shared = root / "app/src/main/assets/rime/shared"
        shared.mkdir(parents=True)
        (shared / "double_pinyin_mspy.schema.yaml").write_text(schema_text, encoding="utf-8")
        (shared / "luna_pinyin.schema.yaml").write_text("schema:\n  schema_id: luna_pinyin\n", encoding="utf-8")
        if with_stroke:
            (shared / "stroke.schema.yaml").write_text(STROKE, encoding="utf-8")
            (shared / "stroke.dict.yaml").write_text("# fixture\n", encoding="utf-8")
        patch = root / "app/src/main/assets/rime/default.custom.yaml"
        patch.parent.mkdir(parents=True, exist_ok=True)
        patch.write_text(patch_text, encoding="utf-8")
        return subprocess.run([sys.executable, str(VALIDATOR), "--root", str(root)],
                              text=True, capture_output=True, check=False)


def main() -> int:
    good = run_case()
    assert good.returncode == 0, good.stdout + good.stderr
    print("PASS: upstream-shaped schema_id, stroke dependency and app selection fixture")

    wrong_id = run_case(schema_text=SCHEMA.replace("double_pinyin_mspy", "another_schema", 1))
    assert wrong_id.returncode == 1, wrong_id.stdout + wrong_id.stderr
    print("PASS: mismatched upstream schema_id is rejected")

    missing_dependency = run_case(schema_text=SCHEMA.replace("    - stroke\n", ""))
    assert missing_dependency.returncode == 1, missing_dependency.stdout + missing_dependency.stderr
    print("PASS: missing stroke dependency declaration is rejected")

    missing_stroke = run_case(with_stroke=False)
    assert missing_stroke.returncode == 1, missing_stroke.stdout + missing_stroke.stderr
    print("PASS: missing stroke schema/dictionary is rejected")

    wrong_selection = run_case(patch_text=PATCH.replace("double_pinyin_mspy", "luna_pinyin"))
    assert wrong_selection.returncode == 1, wrong_selection.stdout + wrong_selection.stderr
    print("PASS: missing Microsoft Shuangpin selection is rejected")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
