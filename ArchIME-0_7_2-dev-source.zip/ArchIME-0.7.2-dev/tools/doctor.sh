#!/usr/bin/env bash
# Report the local Android/native build prerequisites without changing the system.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
errors=0
check_cmd() {
  local label="$1" cmd="$2"
  if command -v "$cmd" >/dev/null 2>&1; then
    printf 'OK   %-22s %s\n' "$label" "$(command -v "$cmd")"
  else
    printf 'MISS %-22s %s not found\n' "$label" "$cmd"
    errors=$((errors + 1))
  fi
}
check_dir() {
  local label="$1" path="$2"
  if [[ -d "$path" ]]; then printf 'OK   %-22s %s\n' "$label" "$path"; else printf 'MISS %-22s %s\n' "$label" "$path"; errors=$((errors + 1)); fi
}

echo 'ArchIME build environment diagnosis'
check_cmd 'Java' java
check_cmd 'Gradle' gradle
check_cmd 'CMake' cmake
check_cmd 'Ninja' ninja
check_cmd 'readelf' readelf
check_cmd 'Python 3' python3
check_cmd 'xmake' xmake
check_cmd 'xrepo' xrepo
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -n "$SDK" ]]; then
  check_dir 'Android SDK' "$SDK"
  [[ -d "$SDK/platforms/android-35" ]] && printf 'OK   %-22s android-35\n' 'SDK platform' || { printf 'MISS %-22s android-35\n' 'SDK platform'; errors=$((errors + 1)); }
  NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
  if [[ -z "$NDK" && -d "$SDK/ndk" ]]; then NDK="$(find "$SDK/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"; fi
  [[ -n "$NDK" ]] && check_dir 'Android NDK' "$NDK" || { echo 'MISS Android NDK          set ANDROID_NDK_HOME'; errors=$((errors + 1)); }
else
  echo 'MISS Android SDK          set ANDROID_HOME or ANDROID_SDK_ROOT'
  errors=$((errors + 1))
fi
[[ -s "$ROOT/app/src/main/cpp/vendor/librime/include/rime_api.h" ]] && echo 'OK   librime header        staged' || { echo 'MISS librime header        not staged'; errors=$((errors + 1)); }
[[ -s "$ROOT/app/src/main/jniLibs/arm64-v8a/librime.so" ]] && echo 'OK   ARM64 librime         staged' || { echo 'MISS ARM64 librime         not staged'; errors=$((errors + 1)); }
if [[ -s "$ROOT/app/src/main/assets/rime/shared/double_pinyin_mspy.schema.yaml" ]]; then
  echo 'OK   Microsoft Shuangpin   schema staged'
  "$ROOT/tools/check_rime_data.sh" || errors=$((errors + 1))
else
  echo 'MISS Microsoft Shuangpin   data not staged'
  errors=$((errors + 1))
fi
if (( errors )); then
  printf '\nRESULT: %d prerequisite(s) missing. No build was attempted.\n' "$errors"
  exit 1
fi
echo '\nRESULT: prerequisites appear present. Run tools/check_native_bundle.sh before building.'

if [[ -x "$ROOT/tools/fetch_rime_data.sh" ]]; then echo "OK: official Rime data fetcher available"; fi
if [[ -s "$ROOT/rime-data.lock" ]]; then echo "OK: Rime upstream commit lock present"; else echo "INFO: Rime upstream commit lock not generated yet (run tools/fetch_rime_data.sh)"; fi
