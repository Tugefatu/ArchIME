#!/usr/bin/env bash
# Build librime for Android arm64-v8a via the official xmake-repo package recipe.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VERSION="${ARCHIME_LIBRIME_VERSION:-1.17.0}"
BUILD_ROOT="${ARCHIME_BUILD_ROOT:-$ROOT/.build/android-arm64}"
PREFIX="${ARCHIME_RIME_PREFIX:-$BUILD_ROOT/librime-prefix}"

usage() {
  cat <<'EOF'
Usage: tools/build_librime_android_xmake.sh [--help|--plan]

Build and stage the xrepo librime package for Android arm64-v8a.
Environment:
  ARCHIME_LIBRIME_VERSION  xrepo package version (default: 1.17.0)
  ARCHIME_RIME_PREFIX     clean staging prefix (default: .build/android-arm64/librime-prefix)
  ANDROID_NDK_HOME        Android NDK root (or ANDROID_NDK_ROOT / SDK ndk/)

--plan prints the exact build steps without installing packages or changing files.
EOF
}
case "${1:-}" in
  --help|-h) usage; exit 0 ;;
  --plan)
    usage
    printf '\nPlanned commands (not executed):\n'
    printf '  xrepo install -p android -a arm64-v8a --ndk="$NDK" -k shared -f "shared=true" "librime %s"\n' "$VERSION"
    printf '  xrepo fetch -p android -a arm64-v8a --ndk="$NDK" --cflags "librime %s"\n' "$VERSION"
    printf '  xrepo fetch -p android -a arm64-v8a --ndk="$NDK" --ldflags "librime %s"\n' "$VERSION"
    printf '  tools/resolve_xrepo_librime.py ... && tools/stage_librime_android.sh "%s"\n' "$PREFIX"
    exit 0
    ;;
  "") ;;
  *) echo "ERROR: unknown option: $1" >&2; usage >&2; exit 2 ;;
esac

for command_name in xrepo python3 readelf; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "ERROR: $command_name not found; install the required build tools first." >&2
    exit 2
  fi
done

NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
if [[ -z "$NDK" && -n "${ANDROID_HOME:-}" && -d "$ANDROID_HOME/ndk" ]]; then
  NDK="$(find "$ANDROID_HOME/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
fi
if [[ -z "$NDK" || ! -d "$NDK" ]]; then
  echo "ERROR: Android NDK not found. Set ANDROID_NDK_HOME or ANDROID_NDK_ROOT." >&2
  exit 2
fi

PACKAGE="librime $VERSION"
echo "Installing $PACKAGE for Android arm64-v8a (shared)"
echo "NDK: $NDK"
xrepo install -p android -a arm64-v8a --ndk="$NDK" -k shared -f "shared=true" "$PACKAGE"

CFLAGS="$(xrepo fetch -p android -a arm64-v8a --ndk="$NDK" --cflags "$PACKAGE")"
LDFLAGS="$(xrepo fetch -p android -a arm64-v8a --ndk="$NDK" --ldflags "$PACKAGE")"
if [[ -z "$CFLAGS" || -z "$LDFLAGS" ]]; then
  echo "ERROR: xrepo returned empty compiler or linker flags; refusing to stage an incomplete package." >&2
  exit 1
fi

mkdir -p "$(dirname "$PREFIX")"
python3 "$ROOT/tools/resolve_xrepo_librime.py" \
  --cflags="$CFLAGS" --ldflags="$LDFLAGS" --prefix "$PREFIX"

"$ROOT/tools/stage_librime_android.sh" "$PREFIX"
"$ROOT/tools/check_native_bundle.sh"
echo "SUCCESS: xrepo artifacts staged. This verifies ELF metadata/dependency closure only; compile the APK and test on-device separately."
