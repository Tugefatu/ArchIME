#!/usr/bin/env bash
# Transactionally stage one matching Android ARM64 librime build.
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/android-librime-prefix" >&2
  echo "Expected include/rime_api.h and lib/ or lib64/ containing librime.so plus its shared dependencies." >&2
  exit 2
fi
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PREFIX="$(cd "$1" && pwd)"
ABI=arm64-v8a
HEADER="$PREFIX/include/rime_api.h"
LIBDIR=""
for candidate in "$PREFIX/lib" "$PREFIX/lib64"; do
  if [[ -s "$candidate/librime.so" ]]; then LIBDIR="$candidate"; break; fi
done
[[ -s "$HEADER" ]] || { echo "ERROR: missing non-empty header: $HEADER" >&2; exit 1; }
[[ -n "$LIBDIR" ]] || { echo "ERROR: cannot find non-empty librime.so under lib/ or lib64/" >&2; exit 1; }
command -v readelf >/dev/null 2>&1 || { echo "ERROR: readelf is required; refusing unverified staging." >&2; exit 2; }

VENDOR="$ROOT/app/src/main/cpp/vendor/librime"
JNI="$ROOT/app/src/main/jniLibs/$ABI"
VENDOR_TMP="$(mktemp -d "$ROOT/app/src/main/cpp/vendor/.librime-stage.XXXXXX")"
JNI_PARENT="$(dirname "$JNI")"
mkdir -p "$JNI_PARENT"
JNI_TMP="$(mktemp -d "$JNI_PARENT/.${ABI}-stage.XXXXXX")"
VENDOR_BACKUP=""
JNI_BACKUP=""
VENDOR_ORIGINAL=0
JNI_ORIGINAL=0
VENDOR_ACTIVATED=0
JNI_ACTIVATED=0
cleanup() {
  rm -rf "$VENDOR_TMP" "$JNI_TMP"
  if [[ -n "$VENDOR_BACKUP" && -d "$VENDOR_BACKUP" ]]; then
    rm -rf "$VENDOR"
    mv "$VENDOR_BACKUP" "$VENDOR"
  elif (( VENDOR_ACTIVATED && ! VENDOR_ORIGINAL )); then
    rm -rf "$VENDOR"
  fi
  if [[ -n "$JNI_BACKUP" && -d "$JNI_BACKUP" ]]; then
    rm -rf "$JNI"
    mv "$JNI_BACKUP" "$JNI"
  elif (( JNI_ACTIVATED && ! JNI_ORIGINAL )); then
    rm -rf "$JNI"
  fi
}
trap cleanup EXIT

mkdir -p "$VENDOR_TMP/include" "$VENDOR_TMP/lib/$ABI"
cp -L "$HEADER" "$VENDOR_TMP/include/rime_api.h"
shopt -s nullglob
libs=("$LIBDIR"/*.so "$LIBDIR"/*.so.*)
shopt -u nullglob
((${#libs[@]} > 0)) || { echo "ERROR: no shared libraries found in $LIBDIR" >&2; exit 1; }
for source in "${libs[@]}"; do
  [[ -f "$source" ]] || continue
  cp -L "$source" "$JNI_TMP/$(basename "$source")"
done
[[ -s "$JNI_TMP/librime.so" ]] || { echo "ERROR: librime.so was not staged" >&2; exit 1; }
cp "$JNI_TMP/librime.so" "$VENDOR_TMP/lib/$ABI/librime.so"

# Validate the entire candidate bundle before touching the currently staged one.
for library in "$JNI_TMP"/*.so*; do
  [[ -f "$library" ]] || continue
  machine="$(readelf -h "$library" | awk -F: '/Machine:/{sub(/^ +/,"",$2); print $2}')"
  [[ "$machine" == *AArch64* ]] || { echo "ERROR: $(basename "$library") is not AArch64: $machine" >&2; exit 1; }
done
ARCHIME_ABI_DIR="$JNI_TMP" "$ROOT/tools/audit_native_bundle.py"

# Both destinations are backed up. On any activation failure the EXIT trap restores them.
if [[ -e "$VENDOR" ]]; then
  VENDOR_ORIGINAL=1
  VENDOR_BACKUP="$ROOT/app/src/main/cpp/vendor/.librime-backup.$$"
  rm -rf "$VENDOR_BACKUP"
  mv "$VENDOR" "$VENDOR_BACKUP"
fi
if [[ -e "$JNI" ]]; then
  JNI_ORIGINAL=1
  JNI_BACKUP="$JNI_PARENT/.${ABI}-backup.$$"
  rm -rf "$JNI_BACKUP"
  mv "$JNI" "$JNI_BACKUP"
fi
mv "$VENDOR_TMP" "$VENDOR"
VENDOR_TMP=""
VENDOR_ACTIVATED=1
mv "$JNI_TMP" "$JNI"
JNI_TMP=""
JNI_ACTIVATED=1
rm -rf "$VENDOR_BACKUP" "$JNI_BACKUP"
VENDOR_BACKUP=""
JNI_BACKUP=""
trap - EXIT
"$ROOT/tools/check_native_bundle.sh"
echo "SUCCESS: matching ARM64 librime header and runtime libraries staged transactionally."
