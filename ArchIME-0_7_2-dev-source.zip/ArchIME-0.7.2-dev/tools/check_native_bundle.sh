#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ABI="arm64-v8a"
ABI_DIR="$ROOT/app/src/main/jniLibs/$ABI"
HEADER="$ROOT/app/src/main/cpp/vendor/librime/include/rime_api.h"
LINK_LIB="$ROOT/app/src/main/cpp/vendor/librime/lib/$ABI/librime.so"
RUNTIME_LIB="$ABI_DIR/librime.so"
SCHEMA="$ROOT/app/src/main/assets/rime/shared/double_pinyin_mspy.schema.yaml"
missing=0
for item in "$HEADER" "$LINK_LIB" "$RUNTIME_LIB" "$SCHEMA"; do
  if [[ -f "$item" ]]; then echo "OK  ${item#"$ROOT"/}"; else echo "MISS ${item#"$ROOT"/}"; missing=1; fi
done
if [[ $missing -ne 0 ]]; then
  echo "Native bundle incomplete. Stage matching header/library and full schema data." >&2
  exit 1
fi
if ! cmp -s "$LINK_LIB" "$RUNTIME_LIB"; then
  echo "ERROR: link-time and packaged librime.so copies differ." >&2
  exit 1
fi
if command -v readelf >/dev/null 2>&1; then
  "$ROOT/tools/audit_native_bundle.py"
else
  echo "ERROR: readelf is required for native dependency auditing." >&2
  exit 2
fi
echo "Packaged shared libraries:"
find "$ABI_DIR" -maxdepth 1 -type f -name '*.so*' -printf '  %f\n' | sort
