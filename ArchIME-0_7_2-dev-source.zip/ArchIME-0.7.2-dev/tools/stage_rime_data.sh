#!/usr/bin/env bash
# Stage Rime shared data from five upstream repositories into Android assets.
set -euo pipefail
if [[ $# -ne 5 ]]; then
  echo "Usage: $0 /path/to/rime-prelude /path/to/rime-essay /path/to/rime-luna-pinyin /path/to/rime-double-pinyin /path/to/rime-stroke" >&2
  exit 2
fi
PRELUDE="$(cd "$1" && pwd)"
ESSAY="$(cd "$2" && pwd)"
BASE="$(cd "$3" && pwd)"
DOUBLE="$(cd "$4" && pwd)"
STROKE="$(cd "$5" && pwd)"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PARENT="$ROOT/app/src/main/assets/rime"
DEST="$PARENT/shared"
required_sources=(
  "$PRELUDE/default.yaml"
  "$ESSAY/essay.txt"
  "$BASE/luna_pinyin.schema.yaml"
  "$BASE/luna_pinyin.dict.yaml"
  "$DOUBLE/double_pinyin_mspy.schema.yaml"
  "$STROKE/stroke.schema.yaml"
  "$STROKE/stroke.dict.yaml"
)
for file in "${required_sources[@]}"; do
  [[ -s "$file" ]] || { echo "Missing or empty upstream data: $file" >&2; exit 1; }
done
mkdir -p "$PARENT"
STAGE="$(mktemp -d "$PARENT/.shared-stage.XXXXXX")"
BACKUP=""
cleanup() {
  [[ -z "$STAGE" ]] || rm -rf "$STAGE"
  if [[ -n "$BACKUP" && -d "$BACKUP" && ! -e "$DEST" ]]; then mv "$BACKUP" "$DEST"; fi
}
trap cleanup EXIT
for source in "$PRELUDE" "$ESSAY" "$BASE" "$DOUBLE" "$STROKE"; do
  cp -a "$source"/. "$STAGE"/
done
for file in default.yaml essay.txt luna_pinyin.schema.yaml luna_pinyin.dict.yaml double_pinyin_mspy.schema.yaml stroke.schema.yaml stroke.dict.yaml; do
  [[ -s "$STAGE/$file" ]] || { echo "Staged file missing/empty: $file" >&2; exit 1; }
done
FIXTURE="$(mktemp -d "$PARENT/.verify-stage.XXXXXX")"
mkdir -p "$FIXTURE/app/src/main/assets/rime/shared" "$FIXTURE/app/src/main/assets/rime"
cp -a "$STAGE"/. "$FIXTURE/app/src/main/assets/rime/shared/"
cp "$ROOT/app/src/main/assets/rime/default.custom.yaml" "$FIXTURE/app/src/main/assets/rime/default.custom.yaml"
if ! python3 "$ROOT/tools/verify_rime_config.py" --root "$FIXTURE"; then
  rm -rf "$FIXTURE"
  exit 1
fi
rm -rf "$FIXTURE"
if [[ -e "$DEST" ]]; then
  BACKUP="$PARENT/.shared-backup.$$"
  rm -rf "$BACKUP"
  mv "$DEST" "$BACKUP"
fi
if mv "$STAGE" "$DEST"; then
  STAGE=""
  [[ -z "$BACKUP" ]] || rm -rf "$BACKUP"
  BACKUP=""
else
  echo 'Failed to activate staged data; old data will be restored.' >&2
  exit 1
fi
trap - EXIT
printf 'Staged Rime shared data from prelude, essay, Luna Pinyin, Microsoft Shuangpin and stroke repositories.\n'
du -sh "$DEST"
