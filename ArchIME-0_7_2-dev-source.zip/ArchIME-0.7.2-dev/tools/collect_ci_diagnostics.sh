#!/usr/bin/env bash
# Collect non-secret environment and build-state diagnostics for failed/successful CI runs.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
OUT="$ROOT/.build/ci-diagnostics.txt"
mkdir -p "$ROOT/.build"
{
  echo "ArchIME CI diagnostics"
  echo "UTC: $(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || true)"
  echo "Runner: ${RUNNER_OS:-unknown} / ${RUNNER_ARCH:-unknown}"
  echo "Git commit: $(git rev-parse HEAD 2>/dev/null || echo unavailable)"
  echo
  for tool in java gradle xmake xrepo cmake readelf python3; do
    echo "### $tool"
    if command -v "$tool" >/dev/null 2>&1; then
      case "$tool" in
        java) java -version 2>&1 | head -n 3 ;;
        gradle) gradle --version 2>&1 | head -n 8 ;;
        xmake|xrepo) "$tool" --version 2>&1 | head -n 4 ;;
        cmake) cmake --version 2>&1 | head -n 2 ;;
        readelf) readelf --version 2>&1 | head -n 1 ;;
        python3) python3 --version 2>&1 ;;
      esac
    else
      echo "not found"
    fi
    echo
  done
  echo "ANDROID_HOME=${ANDROID_HOME:-unset}"
  echo "ANDROID_NDK_HOME=${ANDROID_NDK_HOME:-unset}"
  echo
  echo "### Build files"
  for path in \
    rime-data.lock \
    app/src/main/cpp/vendor/librime/include/rime_api.h \
    app/src/main/jniLibs/arm64-v8a \
    app/build/outputs/apk/debug/app-debug.apk; do
    if [[ -d "$path" ]]; then
      find "$path" -maxdepth 2 -type f -printf '%p (%s bytes)\n' 2>/dev/null | sort
    elif [[ -f "$path" ]]; then
      ls -l "$path"
    else
      echo "MISSING: $path"
    fi
  done
  echo
  echo "### ARM64 ELF headers and dependencies"
  if command -v readelf >/dev/null 2>&1 && [[ -d app/src/main/jniLibs/arm64-v8a ]]; then
    while IFS= read -r -d '' lib; do
      echo "-- $lib"
      readelf -h "$lib" 2>&1 | grep -E 'Class:|Machine:' || true
      readelf -d "$lib" 2>&1 | grep NEEDED || true
    done < <(find app/src/main/jniLibs/arm64-v8a -maxdepth 1 -type f -name '*.so' -print0)
  else
    echo "Native library directory or readelf unavailable"
  fi
  echo
  echo "### Disk"
  df -h . 2>&1 || true
} > "$OUT"
echo "Wrote $OUT"
