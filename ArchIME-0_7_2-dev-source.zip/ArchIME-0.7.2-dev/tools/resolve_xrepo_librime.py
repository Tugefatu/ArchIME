#!/usr/bin/env python3
"""Resolve xrepo -I/-L output and stage a clean librime prefix."""
from __future__ import annotations
import argparse
import hashlib
import shlex
import shutil
import sys
from pathlib import Path


def option_paths(value: str, short: str) -> list[Path]:
    tokens = shlex.split(value)
    found: list[Path] = []
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token == short:
            i += 1
            if i >= len(tokens):
                raise ValueError(f"{short} option has no path")
            found.append(Path(tokens[i]))
        elif token.startswith(short) and len(token) > len(short):
            found.append(Path(token[len(short):]))
        i += 1
    return found


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cflags", required=True)
    parser.add_argument("--ldflags", required=True)
    parser.add_argument("--prefix", required=True, type=Path)
    args = parser.parse_args()
    try:
        include_dirs = option_paths(args.cflags, "-I")
        library_dirs = option_paths(args.ldflags, "-L")
        header = next((d / "rime_api.h" for d in include_dirs
                       if (d / "rime_api.h").is_file()), None)
        if header is None:
            raise ValueError("xrepo cflags did not expose an include directory containing rime_api.h")

        candidates: dict[str, Path] = {}
        for directory in library_dirs:
            if not directory.is_dir():
                continue
            for candidate in sorted(directory.glob("*.so*")):
                if not candidate.is_file():
                    continue
                previous = candidates.get(candidate.name)
                if previous and digest(previous) != digest(candidate):
                    raise ValueError(
                        f"conflicting shared-library basename {candidate.name}: "
                        f"{previous} and {candidate}"
                    )
                candidates.setdefault(candidate.name, candidate)
        if "librime.so" not in candidates:
            raise ValueError(
                "xrepo ldflags did not expose a library directory containing librime.so; "
                "verify the package is installed with -k shared"
            )
        prefix = args.prefix.resolve()
        include_out, lib_out = prefix / "include", prefix / "lib"
        shutil.rmtree(include_out, ignore_errors=True)
        shutil.rmtree(lib_out, ignore_errors=True)
        include_out.mkdir(parents=True, exist_ok=True)
        lib_out.mkdir(parents=True, exist_ok=True)
        shutil.copy2(header, include_out / "rime_api.h")
        for name, source in sorted(candidates.items()):
            shutil.copy2(source, lib_out / name)
        print(f"Resolved header: {header}")
        print(f"Resolved librime: {candidates['librime.so']}")
        print(f"Collected {len(candidates)} shared-library file(s) into {lib_out}")
        return 0
    except (OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
