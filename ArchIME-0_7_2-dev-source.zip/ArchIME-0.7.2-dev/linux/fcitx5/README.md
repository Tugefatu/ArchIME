# Linux target: Fcitx5 + Rime

ArchIME's Linux target is an integration/configuration package, not a native Fcitx5 addon yet.

1. Install `fcitx5`, `fcitx5-rime`, and the Rime data package provided by your distribution.
2. Ensure the upstream schema `double_pinyin_mspy` is installed.
3. Copy `default.custom.yaml` from the Android asset directory to `~/.local/share/fcitx5/rime/` (or the user-data directory configured by your distribution).
4. Deploy/restart Rime through Fcitx5's configuration UI.

Do not copy Android `.so` files into Linux. Linux needs its own native librime build and Fcitx5 integration.
