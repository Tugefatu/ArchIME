Place librime deployment files here during packaging: default.yaml, installation.yaml,
*.schema.yaml and dictionaries. Do not ship an empty directory as a working Rime deployment.
The Microsoft double-pinyin schema must be verified against the upstream Rime schema before release.
