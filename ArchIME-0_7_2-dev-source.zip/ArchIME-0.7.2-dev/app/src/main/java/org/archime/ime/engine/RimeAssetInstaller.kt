package org.archime.ime.engine

import android.content.Context
import java.io.File

/** Installs bundled Rime defaults without overwriting the user's existing configuration. */
object RimeAssetInstaller {
    data class InstallReport(val copied: Int, val kept: Int)

    fun install(context: Context, destination: File): Result<InstallReport> = runCatching {
        var copied = 0
        var kept = 0

        fun copyTree(assetPath: String, output: File) {
            val children = context.assets.list(assetPath).orEmpty()
            if (children.isNotEmpty()) {
                if (!output.exists() && !output.mkdirs()) error("Cannot create ${output.path}")
                children.forEach { child -> copyTree("$assetPath/$child", File(output, child)) }
                return
            }

            if (output.exists()) {
                kept++
                return
            }
            output.parentFile?.let { if (!it.exists() && !it.mkdirs()) error("Cannot create ${it.path}") }
            val temporary = File(output.parentFile, output.name + ".tmp")
            try {
                context.assets.open(assetPath).use { input -> temporary.outputStream().use { outputStream -> input.copyTo(outputStream) } }
                if (!temporary.renameTo(output)) error("Cannot finalize ${output.path}")
                copied++
            } finally {
                temporary.delete()
            }
        }

        copyTree("rime", destination)
        InstallReport(copied, kept)
    }
}
