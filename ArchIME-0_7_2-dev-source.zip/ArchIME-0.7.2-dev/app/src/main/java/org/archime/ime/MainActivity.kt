package org.archime.ime

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** Setup screen: enable ArchIME, pick it as the active keyboard, toggle blur and try typing. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("archime_settings", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF0B1320.toInt())
            setPadding(dp(24), dp(32), dp(24), dp(24))
            fitsSystemWindows = true
        }
        root.addView(ImageView(this).apply { setImageResource(R.drawable.ic_arch_logo) }, LinearLayout.LayoutParams(dp(72), dp(72)))
        root.addView(label("ArchIME", 26f, Color.WHITE).apply { setPadding(0, dp(10), 0, 0) })
        root.addView(label("微软双拼 · Arch 蓝 · 毛玻璃键盘", 13f, 0xFFB7C5D8.toInt()).apply { setPadding(0, dp(4), 0, dp(24)) })

        root.addView(actionButton("1  启用输入法") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        root.addView(actionButton("2  切换到 ArchIME") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        val blurSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        root.addView(Switch(this).apply {
            text = if (blurSupported) "真毛玻璃（Android 12+，实验性）" else "真毛玻璃（需要 Android 12+）"
            setTextColor(Color.WHITE)
            isEnabled = blurSupported
            isChecked = blurSupported && prefs.getBoolean("real_blur", true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("real_blur", on).apply() }
            setPadding(dp(4), dp(14), dp(4), dp(4))
        })
        root.addView(label("切换开关后，重新弹出键盘即可生效。", 11f, 0xFF8292A8.toInt()).apply { setPadding(dp(4), 0, 0, dp(18)) })

        root.addView(EditText(this).apply {
            hint = "在这里试试输入（微软双拼：英=y; 行=x;）"
            setHintTextColor(0xFF8292A8.toInt())
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(0x331793D1); cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0x881793D1.toInt())
            }
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun label(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
    }

    private fun actionButton(value: String, onClick: () -> Unit) = Button(this).apply {
        text = value
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(0xFF1793D1.toInt()); cornerRadius = dp(14).toFloat() }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)).apply { setMargins(0, dp(6), 0, dp(6)) }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
