cmake_minimum_required(VERSION 3.22.1)
project(archime_rime LANGUAGES CXX)

add_library(archime_rime SHARED native_bridge.cpp)
target_compile_features(archime_rime PRIVATE cxx_std_17)

find_library(log-lib log REQUIRED)
target_link_libraries(archime_rime PRIVATE ${log-lib})

# Keep the CMake-imported link input outside jniLibs. Gradle packages the
# runtime copy from jniLibs; this avoids AGP duplicate-native-library conflicts.
set(RIME_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/vendor/librime")
set(RIME_INCLUDE_DIR "${RIME_ROOT}/include")
set(RIME_LIBRARY "${RIME_ROOT}/lib/${ANDROID_ABI}/librime.so")
set(RIME_RUNTIME_LIBRARY "${CMAKE_CURRENT_SOURCE_DIR}/../jniLibs/${ANDROID_ABI}/librime.so")

if(EXISTS "${RIME_INCLUDE_DIR}/rime_api.h" AND
   EXISTS "${RIME_LIBRARY}" AND
   EXISTS "${RIME_RUNTIME_LIBRARY}")
    add_library(librime SHARED IMPORTED GLOBAL)
    set_target_properties(librime PROPERTIES IMPORTED_LOCATION "${RIME_LIBRARY}")
    target_include_directories(archime_rime PRIVATE "${RIME_INCLUDE_DIR}")
    target_link_libraries(archime_rime PRIVATE librime)
    target_compile_definitions(archime_rime PRIVATE ARCHIME_RIME_DEPENDENCY_STAGED=1)
    message(STATUS "ArchIME: matching librime header, link input and runtime copy found")
elseif(EXISTS "${RIME_LIBRARY}" OR
       EXISTS "${RIME_RUNTIME_LIBRARY}" OR
       EXISTS "${RIME_INCLUDE_DIR}/rime_api.h")
    message(FATAL_ERROR "Incomplete librime staging. Run tools/stage_librime_android.sh <android-librime-prefix> to stage the matching header and libraries.")
else()
    message(STATUS "ArchIME: building fail-closed JNI stub; librime is not staged")
endif()
