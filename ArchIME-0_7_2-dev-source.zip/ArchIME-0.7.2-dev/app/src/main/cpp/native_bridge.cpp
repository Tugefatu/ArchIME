#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <type_traits>
#include <vector>

#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
#include "rime_api.h"

// Compile-time ABI contract against the exact staged upstream rime_api.h.
// These assertions intentionally fail the Android native build if an
// incompatible/modified header changes a function signature used below.
static_assert(std::is_same_v<decltype(RimeApi::setup), void (*)(RimeTraits*)>,
              "Unexpected librime RimeApi::setup signature");
static_assert(std::is_same_v<decltype(RimeApi::initialize), void (*)(RimeTraits*)>,
              "Unexpected librime RimeApi::initialize signature");
static_assert(std::is_same_v<decltype(RimeApi::start_maintenance), Bool (*)(Bool)>,
              "Unexpected librime RimeApi::start_maintenance signature");
static_assert(std::is_same_v<decltype(RimeApi::join_maintenance_thread), void (*)(void)>,
              "Unexpected librime RimeApi::join_maintenance_thread signature");
static_assert(std::is_same_v<decltype(RimeApi::create_session), RimeSessionId (*)(void)>,
              "Unexpected librime RimeApi::create_session signature");
static_assert(std::is_same_v<decltype(RimeApi::select_schema), Bool (*)(RimeSessionId, const char*)>,
              "Unexpected librime RimeApi::select_schema signature");
static_assert(std::is_same_v<decltype(RimeApi::process_key), Bool (*)(RimeSessionId, int, int)>,
              "Unexpected librime RimeApi::process_key signature");
static_assert(std::is_same_v<decltype(RimeApi::get_context), Bool (*)(RimeSessionId, RimeContext*)>,
              "Unexpected librime RimeApi::get_context signature");
static_assert(std::is_same_v<decltype(RimeApi::select_candidate_on_current_page),
                             Bool (*)(RimeSessionId, size_t)>,
              "Unexpected librime RimeApi::select_candidate_on_current_page signature");
static_assert(std::is_same_v<decltype(RimeApi::destroy_session), Bool (*)(RimeSessionId)>,
              "Unexpected librime RimeApi::destroy_session signature");
static_assert(std::is_same_v<decltype(RimeApi::finalize), void (*)(void)>,
              "Unexpected librime RimeApi::finalize signature");
static_assert(std::is_same_v<decltype(RimeApi::set_notification_handler),
                             void (*)(RimeNotificationHandler, void*)>,
              "Unexpected librime RimeApi::set_notification_handler signature");
#endif

namespace {
constexpr const char* kLogTag = "ArchIME-Rime";
#define RIME_LOGI(...) __android_log_print(ANDROID_LOG_INFO, kLogTag, __VA_ARGS__)
#define RIME_LOGW(...) __android_log_print(ANDROID_LOG_WARN, kLogTag, __VA_ARGS__)
#define RIME_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, kLogTag, __VA_ARGS__)

#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
void onRimeNotification(void*, RimeSessionId session, const char* type, const char* value) {
    RIME_LOGI("notification session=%llu type=%s value=%s",
              static_cast<unsigned long long>(session),
              type ? type : "", value ? value : "");
}
#endif

struct EngineHandle {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    RimeApi* api = nullptr;
    RimeSessionId session = 0;
    bool owns_runtime = false;
#endif
};

jobject makeUpdate(JNIEnv* env, const std::string& composing,
                   const std::vector<std::pair<std::string, std::string>>& items,
                   bool ready, const std::string& commit) {
    jclass updateClass = env->FindClass("org/archime/ime/engine/InputEngine$Update");
    if (!updateClass) return nullptr;
    jmethodID ctor = env->GetMethodID(updateClass, "<init>",
        "(Ljava/lang/String;Ljava/util/List;ZLjava/lang/String;)V");
    if (!ctor) { env->DeleteLocalRef(updateClass); return nullptr; }
    jstring composingText = env->NewStringUTF(composing.c_str());
    jstring commitText = env->NewStringUTF(commit.c_str());
    jclass arrayListClass = env->FindClass("java/util/ArrayList");
    jmethodID listCtor = env->GetMethodID(arrayListClass, "<init>", "()V");
    jmethodID add = env->GetMethodID(arrayListClass, "add", "(Ljava/lang/Object;)Z");
    jobject list = env->NewObject(arrayListClass, listCtor);
    jclass candidateClass = env->FindClass("org/archime/ime/engine/InputEngine$Candidate");
    jmethodID candidateCtor = env->GetMethodID(candidateClass, "<init>",
        "(Ljava/lang/String;Ljava/lang/String;)V");
    for (const auto& item : items) {
        jstring text = env->NewStringUTF(item.first.c_str());
        jstring comment = env->NewStringUTF(item.second.c_str());
        jobject candidate = env->NewObject(candidateClass, candidateCtor, text, comment);
        env->CallBooleanMethod(list, add, candidate);
        env->DeleteLocalRef(candidate);
        env->DeleteLocalRef(comment);
        env->DeleteLocalRef(text);
    }
    jobject result = env->NewObject(updateClass, ctor, composingText, list,
                                    ready ? JNI_TRUE : JNI_FALSE, commitText);
    env->DeleteLocalRef(candidateClass);
    env->DeleteLocalRef(arrayListClass);
    env->DeleteLocalRef(list);
    env->DeleteLocalRef(commitText);
    env->DeleteLocalRef(composingText);
    env->DeleteLocalRef(updateClass);
    return result;
}

jobject unavailable(JNIEnv* env) {
    return makeUpdate(env, "", {}, false, "");
}

#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
std::string takeCommit(EngineHandle* h) {
    if (!h || !h->api || !h->session ||
        !RIME_API_AVAILABLE(h->api, get_commit) ||
        !RIME_API_AVAILABLE(h->api, free_commit)) return {};
    RIME_STRUCT(RimeCommit, commit);
    if (!h->api->get_commit(h->session, &commit)) return {};
    std::string text = commit.text ? commit.text : "";
    h->api->free_commit(&commit);
    return text;
}

jobject snapshot(JNIEnv* env, EngineHandle* h, const std::string& commit = {}) {
    if (!h || !h->api || !h->session) return unavailable(env);
    std::string composing;
    std::vector<std::pair<std::string, std::string>> candidates;
    if (!RIME_API_AVAILABLE(h->api, get_context) ||
        !RIME_API_AVAILABLE(h->api, free_context)) return unavailable(env);
    RIME_STRUCT(RimeContext, context);
    if (h->api->get_context(h->session, &context)) {
        if (context.composition.preedit) composing = context.composition.preedit;
        for (int i = 0; context.menu.candidates && i < context.menu.num_candidates; ++i) {
            const auto& c = context.menu.candidates[i];
            candidates.emplace_back(c.text ? c.text : "", c.comment ? c.comment : "");
        }
        h->api->free_context(&context);
    }
    return makeUpdate(env, composing, candidates, true, commit);
}
#endif
}

extern "C" JNIEXPORT jlong JNICALL
Java_org_archime_ime_engine_NativeRimeEngine_nativeCreate(JNIEnv* env, jobject, jstring userDir) {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    if (!userDir) return 0;
    const char* path = env->GetStringUTFChars(userDir, nullptr);
    if (!path) return 0;
    std::string userData(path);
    env->ReleaseStringUTFChars(userDir, path);
    std::string sharedData = userData + "/shared";
    auto* h = new EngineHandle();
    h->api = rime_get_api();
    // RimeApi is versioned: checking a raw function pointer is not enough
    // when an older header/runtime pair exposes a shorter structure.
    if (!h->api ||
        !RIME_API_AVAILABLE(h->api, setup) ||
        !RIME_API_AVAILABLE(h->api, initialize) ||
        !RIME_API_AVAILABLE(h->api, start_maintenance) ||
        !RIME_API_AVAILABLE(h->api, join_maintenance_thread) ||
        !RIME_API_AVAILABLE(h->api, create_session) ||
        !RIME_API_AVAILABLE(h->api, select_schema) ||
        !RIME_API_AVAILABLE(h->api, destroy_session) ||
        !RIME_API_AVAILABLE(h->api, finalize)) {
        delete h;
        return 0;
    }
    RIME_STRUCT(RimeTraits, traits);
    traits.app_name = "rime.archime";
    traits.shared_data_dir = sharedData.c_str();
    traits.user_data_dir = userData.c_str();
    RIME_LOGI("setup shared_data_dir=%s user_data_dir=%s", sharedData.c_str(), userData.c_str());
    h->api->setup(&traits);
    if (RIME_API_AVAILABLE(h->api, set_notification_handler)) {
        h->api->set_notification_handler(&onRimeNotification, nullptr);
    }
    h->api->initialize(nullptr);
    h->owns_runtime = true;
    RIME_LOGI("librime initialized");

    // Rime's maintenance thread compiles schemas/dictionaries on first launch.
    // A false return means no maintenance thread was started; do not join it.
    if (h->api->start_maintenance(1)) {
        RIME_LOGI("waiting for Rime maintenance/deployment");
        h->api->join_maintenance_thread();
        RIME_LOGI("Rime maintenance/deployment finished");
    } else {
        RIME_LOGI("Rime maintenance not required or already running");
    }

    h->session = h->api->create_session();
    if (!h->session) {
        RIME_LOGE("create_session failed");
        if (RIME_API_AVAILABLE(h->api, set_notification_handler))
            h->api->set_notification_handler(nullptr, nullptr);
        h->api->finalize();
        delete h;
        return 0;
    }
    // Fail closed unless the requested Microsoft Shuangpin schema is available.
    if (!h->api->select_schema(h->session, "double_pinyin_mspy")) {
        RIME_LOGE("Microsoft Shuangpin schema 'double_pinyin_mspy' could not be selected");
        h->api->destroy_session(h->session);
        if (RIME_API_AVAILABLE(h->api, set_notification_handler))
            h->api->set_notification_handler(nullptr, nullptr);
        h->api->finalize();
        delete h;
        return 0;
    }
    if (RIME_API_AVAILABLE(h->api, get_version)) {
        const char* version = h->api->get_version();
        RIME_LOGI("ready; librime version=%s", version ? version : "unknown");
    } else {
        RIME_LOGI("ready; librime version API unavailable");
    }
    return reinterpret_cast<jlong>(h);
#else
    (void)env;
    return 0;
#endif
}

extern "C" JNIEXPORT jobject JNICALL
Java_org_archime_ime_engine_NativeRimeEngine_nativeProcessKey(JNIEnv* env, jobject, jlong handle, jint codePoint) {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    auto* h = reinterpret_cast<EngineHandle*>(handle);
    if (!h || !h->api || !h->session || codePoint < 0 || codePoint > 0x7f) return unavailable(env);
    if (!RIME_API_AVAILABLE(h->api, process_key) ||
        !RIME_API_AVAILABLE(h->api, get_context) ||
        !RIME_API_AVAILABLE(h->api, get_commit)) return unavailable(env);
    h->api->process_key(h->session, static_cast<int>(codePoint), 0);
    return snapshot(env, h, takeCommit(h));
#else
    (void)handle; (void)codePoint; return unavailable(env);
#endif
}

extern "C" JNIEXPORT jobject JNICALL
Java_org_archime_ime_engine_NativeRimeEngine_nativeSelectCandidate(JNIEnv* env, jobject, jlong handle, jint index) {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    auto* h = reinterpret_cast<EngineHandle*>(handle);
    if (!h || !h->api || !h->session || index < 0) return unavailable(env);
    if (!RIME_API_AVAILABLE(h->api, select_candidate_on_current_page) ||
        !RIME_API_AVAILABLE(h->api, get_context) ||
        !RIME_API_AVAILABLE(h->api, get_commit)) return unavailable(env);
    h->api->select_candidate_on_current_page(h->session, static_cast<size_t>(index));
    return snapshot(env, h, takeCommit(h));
#else
    (void)handle; (void)index; return unavailable(env);
#endif
}


extern "C" JNIEXPORT jobject JNICALL
Java_org_archime_ime_engine_NativeRimeEngine_nativeChangePage(JNIEnv* env, jobject, jlong handle, jboolean backward) {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    auto* h = reinterpret_cast<EngineHandle*>(handle);
    if (!h || !h->api || !h->session ||
        !RIME_API_AVAILABLE(h->api, change_page) ||
        !RIME_API_AVAILABLE(h->api, get_context) ||
        !RIME_API_AVAILABLE(h->api, get_commit)) return unavailable(env);
    h->api->change_page(h->session, backward ? 1 : 0);
    return snapshot(env, h, takeCommit(h));
#else
    (void)handle; (void)backward; return unavailable(env);
#endif
}

extern "C" JNIEXPORT jobject JNICALL
Java_org_archime_ime_engine_NativeRimeEngine_nativeBackspace(JNIEnv* env, jobject, jlong handle) {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    auto* h = reinterpret_cast<EngineHandle*>(handle);
    if (!h || !h->api || !h->session) return unavailable(env);
    if (!RIME_API_AVAILABLE(h->api, process_key) ||
        !RIME_API_AVAILABLE(h->api, get_context) ||
        !RIME_API_AVAILABLE(h->api, get_commit)) return unavailable(env);
    h->api->process_key(h->session, 0xff08, 0);
    return snapshot(env, h, takeCommit(h));
#else
    (void)handle; return unavailable(env);
#endif
}

extern "C" JNIEXPORT jobject JNICALL
Java_org_archime_ime_engine_NativeRimeEngine_nativeClear(JNIEnv* env, jobject, jlong handle) {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    auto* h = reinterpret_cast<EngineHandle*>(handle);
    if (!h || !h->api || !h->session) return unavailable(env);
    if (!RIME_API_AVAILABLE(h->api, clear_composition) ||
        !RIME_API_AVAILABLE(h->api, get_context)) return unavailable(env);
    h->api->clear_composition(h->session);
    return snapshot(env, h);
#else
    (void)handle; return unavailable(env);
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_org_archime_ime_engine_NativeRimeEngine_nativeDestroy(JNIEnv*, jobject, jlong handle) {
#if defined(ARCHIME_RIME_DEPENDENCY_STAGED)
    auto* h = reinterpret_cast<EngineHandle*>(handle);
    if (!h) return;
    if (h->api && h->session) h->api->destroy_session(h->session);
    if (h->api && h->owns_runtime) {
        if (RIME_API_AVAILABLE(h->api, set_notification_handler))
            h->api->set_notification_handler(nullptr, nullptr);
        h->api->finalize();
        RIME_LOGI("librime finalized");
    }
    delete h;
#else
    (void)handle;
#endif
}
